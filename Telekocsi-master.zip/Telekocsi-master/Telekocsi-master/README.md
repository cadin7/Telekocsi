# Telekocsi

Funkcionális követelmények:

Vendégként szeretném a főoldalon látni a legújabb meghírdetett utakat
Vendégként szeretnék böngészni az aktuálisan meghírdetett utak között
Vendégként szeretnék keresni különböző adatok szerint
Vendégként szeretnék tudni regisztrálni az oldalra
Felhasználóként szeretnék tudni bejelentkezni az oldalra
Felhasználóként szeretném tudni a profiladataimat szerkeszteni
Felhasználóként szeretnék utakat meghírdetni
Felhasználóként szeretném a saját hírdetéseimet módosítani vagy törölni

Nem funkcionális követelmények:

Felhasználóbarát, ergonomikus elrendezés és kinézet
Gyors, megbízható működés
Biztonságos működés: jelszavak tárolása, funkciókhoz való hozzáférés